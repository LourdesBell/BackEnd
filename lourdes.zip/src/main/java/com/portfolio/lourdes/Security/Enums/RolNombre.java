package com.portfolio.lourdes.Security.Enums;

public enum RolNombre {
    ROLE_ADMIN, ROLE_USER
}
