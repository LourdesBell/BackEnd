package com.portfolio.lourdes;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class LourdesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LourdesApplication.class, args);
	}

}

