package com.portfolio.lourdes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LourdesApplicationTests {

	@Test
	void contextLoads() {
	}

}
